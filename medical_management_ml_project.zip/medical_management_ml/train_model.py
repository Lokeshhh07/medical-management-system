"""Train a clearly labelled educational demo classifier using synthetic data.
This dataset is generated for software/ML coursework and is NOT clinical data.
Do not use this model for diagnosis, treatment, or decisions about real patients.
"""
import os
import numpy as np
import joblib
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

ROOT = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(ROOT, "models")
os.makedirs(MODEL_DIR, exist_ok=True)
OUT = os.path.join(MODEL_DIR, "diabetes_demo_model.joblib")

# Create an offline reproducible synthetic dataset with eight input columns.
X, y = make_classification(
    n_samples=1800, n_features=8, n_informative=6, n_redundant=1,
    n_repeated=0, n_classes=2, weights=[0.62, 0.38], class_sep=0.8,
    flip_y=0.04, random_state=42
)
X = np.abs(X)
# Rescale synthetic columns into plausible-looking ranges for the demo UI.
ranges = [(0, 12), (65, 200), (40, 120), (0, 60), (0, 350), (15, 50), (0.05, 2.0), (18, 85)]
for i, (lo, hi) in enumerate(ranges):
    col = X[:, i]
    cmin, cmax = col.min(), col.max()
    X[:, i] = lo + (col - cmin) / (cmax - cmin + 1e-9) * (hi - lo)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
model = Pipeline([
    ("scale", StandardScaler()),
    ("classifier", LogisticRegression(max_iter=1500, random_state=42))
])
model.fit(X_train, y_train)
pred = model.predict(X_test)
print("EDUCATIONAL DEMO ONLY — synthetic data, not clinically valid.")
print(f"Holdout accuracy: {accuracy_score(y_test, pred):.3f}")
print("Confusion matrix:\n", confusion_matrix(y_test, pred))
print(classification_report(y_test, pred, target_names=["Lower demo flag", "Higher demo flag"]))
joblib.dump(model, OUT)
print(f"Saved model to: {OUT}")
