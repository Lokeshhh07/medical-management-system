@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python nahi mila. Python 3.10-3.12 install karke dobara try karein.
  pause
  exit /b 1
)
if not exist .venv (
  python -m venv .venv
  if errorlevel 1 goto failed
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if errorlevel 1 goto failed
if not exist models\diabetes_demo_model.joblib python train_model.py
if errorlevel 1 goto failed
python app.py
pause
exit /b 0
:failed
echo Setup mein problem aayi. Error upar check karein.
pause
exit /b 1
