from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3, os
from datetime import datetime
import joblib
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "medical.db")
MODEL_PATH = os.path.join(BASE_DIR, "models", "diabetes_demo_model.joblib")

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev-only-change-this-key")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS patients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, age INTEGER NOT NULL, gender TEXT NOT NULL,
            phone TEXT, email TEXT, created_at TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL, doctor TEXT NOT NULL,
            appointment_date TEXT NOT NULL, appointment_time TEXT NOT NULL,
            reason TEXT, status TEXT NOT NULL DEFAULT 'Scheduled',
            FOREIGN KEY(patient_id) REFERENCES patients(id)
        )""")
        conn.commit()

init_db()  # Also initialize the database when served by a production WSGI server.

def load_model():
    if not os.path.exists(MODEL_PATH):
        return None
    return joblib.load(MODEL_PATH)

@app.route("/health")
def health():
    return {"status": "ok"}, 200

@app.route("/")
def dashboard():
    with get_db() as conn:
        patients = conn.execute("SELECT COUNT(*) AS n FROM patients").fetchone()["n"]
        appointments = conn.execute("SELECT COUNT(*) AS n FROM appointments").fetchone()["n"]
        upcoming = conn.execute("""SELECT a.*, p.name AS patient_name
            FROM appointments a JOIN patients p ON p.id=a.patient_id
            ORDER BY a.appointment_date, a.appointment_time LIMIT 5""").fetchall()
        recent = conn.execute("SELECT * FROM patients ORDER BY id DESC LIMIT 5").fetchall()
    return render_template("dashboard.html", patients=patients, appointments=appointments,
                           upcoming=upcoming, recent=recent)

@app.route("/patients", methods=["GET", "POST"])
def patients():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        age_raw = request.form.get("age", "").strip()
        gender = request.form.get("gender", "").strip()
        if not name or not age_raw or not gender:
            flash("Name, age aur gender zaroori hain.", "error")
            return redirect(url_for("patients"))
        try:
            age = int(age_raw)
            if age < 0 or age > 120:
                raise ValueError
        except ValueError:
            flash("Age 0 se 120 ke beech enter karein.", "error")
            return redirect(url_for("patients"))
        with get_db() as conn:
            conn.execute("INSERT INTO patients(name, age, gender, phone, email, created_at) VALUES(?,?,?,?,?,?)",
                         (name, age, gender, request.form.get("phone","").strip(),
                          request.form.get("email","").strip(), datetime.now().strftime("%Y-%m-%d %H:%M")))
            conn.commit()
        flash("Patient record successfully add ho gaya.", "success")
        return redirect(url_for("patients"))
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM patients ORDER BY id DESC").fetchall()
    return render_template("patients.html", patients=rows)

@app.route("/patients/delete/<int:patient_id>", methods=["POST"])
def delete_patient(patient_id):
    with get_db() as conn:
        conn.execute("DELETE FROM appointments WHERE patient_id=?", (patient_id,))
        conn.execute("DELETE FROM patients WHERE id=?", (patient_id,))
        conn.commit()
    flash("Patient aur uski appointments delete kar di gayi.", "success")
    return redirect(url_for("patients"))

@app.route("/appointments", methods=["GET", "POST"])
def appointments():
    if request.method == "POST":
        try:
            patient_id = int(request.form["patient_id"])
            date = request.form["appointment_date"]
            time = request.form["appointment_time"]
            doctor = request.form["doctor"].strip()
            if not doctor or not date or not time:
                raise ValueError
            with get_db() as conn:
                exists = conn.execute("SELECT id FROM patients WHERE id=?", (patient_id,)).fetchone()
                if not exists:
                    raise ValueError
                conn.execute("""INSERT INTO appointments(patient_id, doctor, appointment_date,
                    appointment_time, reason, status) VALUES(?,?,?,?,?,?)""",
                    (patient_id, doctor, date, time, request.form.get("reason","").strip(), "Scheduled"))
                conn.commit()
            flash("Appointment book ho gayi.", "success")
        except (ValueError, KeyError):
            flash("Appointment ke liye valid patient aur saari required details enter karein.", "error")
        return redirect(url_for("appointments"))
    with get_db() as conn:
        people = conn.execute("SELECT id, name FROM patients ORDER BY name").fetchall()
        rows = conn.execute("""SELECT a.*, p.name AS patient_name FROM appointments a
            JOIN patients p ON p.id=a.patient_id
            ORDER BY a.appointment_date, a.appointment_time""").fetchall()
    return render_template("appointments.html", patients=people, appointments=rows)

@app.route("/appointments/status/<int:appointment_id>", methods=["POST"])
def appointment_status(appointment_id):
    status = request.form.get("status", "Scheduled")
    if status not in ("Scheduled", "Completed", "Cancelled"):
        status = "Scheduled"
    with get_db() as conn:
        conn.execute("UPDATE appointments SET status=? WHERE id=?", (status, appointment_id))
        conn.commit()
    flash("Appointment status update ho gaya.", "success")
    return redirect(url_for("appointments"))

@app.route("/predict", methods=["GET", "POST"])
def predict():
    prediction = None
    error = None
    if request.method == "POST":
        try:
            values = [
                float(request.form["pregnancies"]),
                float(request.form["glucose"]),
                float(request.form["blood_pressure"]),
                float(request.form["skin_thickness"]),
                float(request.form["insulin"]),
                float(request.form["bmi"]),
                float(request.form["pedigree"]),
                float(request.form["age"]),
            ]
            if any(v < 0 for v in values) or values[1] > 500 or values[2] > 300 or values[5] > 100 or values[7] > 120:
                raise ValueError
            model = load_model()
            if model is None:
                error = "ML model abhi train nahi hua. Terminal mein `python train_model.py` run karein."
            else:
                result = int(model.predict(np.array(values).reshape(1, -1))[0])
                probability = float(model.predict_proba(np.array(values).reshape(1, -1))[0][1])
                prediction = {"label": "Higher demo-model flag" if result == 1 else "Lower demo-model flag",
                              "probability": round(probability * 100, 1)}
        except (ValueError, KeyError):
            error = "Please valid non-negative numeric values enter karein."
    return render_template("predict.html", prediction=prediction, error=error)

@app.route("/about")
def about():
    return render_template("about.html")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)
