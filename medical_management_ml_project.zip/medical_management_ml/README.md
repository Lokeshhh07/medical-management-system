# Smart Medical Management System — ML Assignment

Responsive Flask website for laptop and mobile browsers. Features: dashboard, patient records, appointments, and an educational ML prediction page. Uses Python, Flask, SQLite, HTML/CSS, and scikit-learn Logistic Regression.

## Easiest setup on Windows
1. Install Python 3.10–3.12 from https://www.python.org/downloads/ (enable “Add Python to PATH”).
2. Extract this ZIP.
3. Double-click `run_windows.bat`. The first run installs dependencies and can take a few minutes; keep the terminal open.
4. Open `http://127.0.0.1:5000` in the laptop browser.

Manual Windows setup: open terminal in the project folder and run `python -m venv .venv`, `.venv\Scripts\activate`, `pip install -r requirements.txt`, `python train_model.py`, then `python app.py`.

## macOS/Linux
Run `chmod +x run_mac_linux.sh`, then `./run_mac_linux.sh`. Open `http://127.0.0.1:5000`.

## Use on a phone
- Laptop and phone on the same Wi-Fi: run the app on the laptop, find the laptop's local IP address, and open `http://LAPTOP-IP:5000` on the phone. The network/firewall must allow the connection.
- Use from anywhere: deploy the project to a Python web host such as Render. This ZIP includes `render.yaml` and `Procfile` to help deployment. A public URL is created by the hosting provider; it cannot be generated from this ZIP alone. Do not use real patient information on this demo deployment. Free-host filesystems may reset, so the SQLite data may not persist.

## ML model note — important
The included `models/diabetes_demo_model.joblib` is an educational classifier trained using synthetic generated data. It is **not clinically validated** and its output is not a real diabetes diagnosis, medical risk estimate, or treatment recommendation. The prediction page labels its result as a demo-model flag. For a research-grade assignment, replace the synthetic dataset with a suitably licensed public dataset and document its source, preprocessing, metrics, and limitations.

## Security note
This is a student prototype, not a production hospital system. It has no user authentication/authorization and should only use dummy data. Real deployments need access controls, secure secret management, privacy review, encryption, backups, and a persistent database.

## Project files
- `app.py` — Flask routes, database operations, prediction endpoint
- `train_model.py` — creates synthetic demo data, trains/evaluates Logistic Regression, saves the pipeline
- `models/diabetes_demo_model.joblib` — trained demo model
- `templates/` — responsive HTML pages
- `static/style.css` — responsive interface styles
- `medical.db` — created automatically at runtime
