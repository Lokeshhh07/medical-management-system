#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
if [ ! -f models/diabetes_demo_model.joblib ]; then python train_model.py; fi
python app.py
