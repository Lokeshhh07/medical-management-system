Run `python train_model.py` from the project root to generate diabetes_demo_model.joblib.
